module.exports = {
    api: '/api/',
    timeout: 30000
}
