<template>
    <div class="block dr-pagination">
        <div v-if="pageInfo">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"  :current-page.sync="pageInfo.current" :page-size="pageInfo.pageSize" layout="total, prev, pager, next" :total="pageInfo.totalItems">
            </el-pagination>
        </div>
    </div>
</template>
<style lang="">
.dr-pagination {
    text-align: center;
    margin: 15px auto;
}
</style>
<script>
export default {
    props: {
        pageInfo: Object,
        pageType: String,
        query:{},
    },
    methods: {
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
            this.$store.dispatch('getAdminUserList', {
                pageSize: val
            });
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
            if (this.pageType === 'content') {
                console.log('query:',this.query)
                this.$store.dispatch('getContentList', Object.assign({
                    current: val,
                    model:'all',
                },this.query));
            } else if (this.pageType === 'adminUser') {
                this.$store.dispatch('getAdminUserList', {
                    current: val
                });
            } else if (this.pageType === 'adminGroup') {
                this.$store.dispatch('getAdminGroupList', {
                    current: val
                });
            } else if (this.pageType === 'contentMessage') {
                this.$store.dispatch('getContentMessageList', {
                    current: val
                });
            } else if (this.pageType === 'contentTag') {
                this.$store.dispatch('getContentTagList', {
                    current: val
                });
            } else if (this.pageType === 'regUser') {
                this.$store.dispatch('getRegUserList', {
                    current: val
                });
            } else if (this.pageType === 'backUpData') {
                this.$store.dispatch('getBakDateList', {
                    current: val
                });
            } else if (this.pageType === 'systemOptionLogs') {
                this.$store.dispatch('getSystemLogsList', {
                    current: val
                });
            } else if (this.pageType === 'systemNotify') {
                this.$store.dispatch('getSystemNotifyList', {
                    current: val
                });
            } else if (this.pageType === 'systemAnnounce') {
                this.$store.dispatch('getSystemAnnounceList', {
                    current: val
                });
            } else if (this.pageType === 'ads') {
                this.$store.dispatch('getAdsList', {
                    current: val
                });
            }

        }
    },
    data() {

        return {

        };
    }
}
</script>