<template>
    <div class="loadingbox">
        loading...
    </div>
</template>
<script>
export default {
    data() {
        return {
            msg: '^_^~'
        }
    }
}
</script>
<style>
.loadingbox {
    color: royalblue
}
</style>